Put the matching original image(s) in this folder. Keep the filenames listed in the main README where applicable.
